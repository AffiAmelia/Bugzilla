# frozen_string_literal: true

require 'test_helper'

class BugControllerTest < ActionDispatch::IntegrationTest
  # test "the truth" do
  #   assert true
  # end
end
